<template>
  <div class="main-content">
    <div class="page-content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-xl-3 col-md-6">
            <div class="card mini-stat bg-primary text-white">
              <div class="card-body">
                <div class="mb-4">
                  <div class="float-left mini-stat-img mr-4">
                    <img
                      src="../../assets/images/services-icon/01.png"
                      alt=""
                    />
                  </div>
                  <h5 class="font-size-16 text-uppercase mt-0 text-white-50">
                    乘客活跃数
                  </h5>
                  <h4 class="font-weight-medium font-size-24">
                    1,685 <i class="mdi mdi-arrow-up text-success ml-2"></i>
                  </h4>
                  <div class="mini-stat-label bg-success">
                    <p class="mb-0">+ 12%</p>
                  </div>
                </div>
                <div class="pt-2">
                  <div class="float-right">
                    <a href="#" class="text-white-50"
                      ><i class="mdi mdi-arrow-right h5"></i
                    ></a>
                  </div>

                  <p class="text-white-50 mb-0 mt-1">Since last month</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-md-6">
            <div class="card mini-stat bg-primary text-white">
              <div class="card-body">
                <div class="mb-4">
                  <div class="float-left mini-stat-img mr-4">
                    <img
                      src="../../assets/images/services-icon/02.png"
                      alt=""
                    />
                  </div>
                  <h5 class="font-size-16 text-uppercase mt-0 text-white-50">
                    机组人员活跃数
                  </h5>
                  <h4 class="font-weight-medium font-size-24">
                    368 <i class="mdi mdi-arrow-down text-danger ml-2"></i>
                  </h4>
                  <div class="mini-stat-label bg-danger">
                    <p class="mb-0">- 1%</p>
                  </div>
                </div>
                <div class="pt-2">
                  <div class="float-right">
                    <a href="#" class="text-white-50"
                      ><i class="mdi mdi-arrow-right h5"></i
                    ></a>
                  </div>

                  <p class="text-white-50 mb-0 mt-1">Since last month</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-md-6">
            <div class="card mini-stat bg-primary text-white">
              <div class="card-body">
                <div class="mb-4">
                  <div class="float-left mini-stat-img mr-4">
                    <img
                      src="../../assets/images/services-icon/04.png"
                      alt=""
                    />
                  </div>
                  <h5 class="font-size-16 text-uppercase mt-0 text-white-50">
                    机场工作人员活跃数
                  </h5>
                  <h4 class="font-weight-medium font-size-24">
                    158 <i class="mdi mdi-arrow-up text-success ml-2"></i>
                  </h4>
                  <div class="mini-stat-label bg-info">
                    <p class="mb-0">+2%</p>
                  </div>
                </div>
                <div class="pt-2">
                  <div class="float-right">
                    <a href="#" class="text-white-50"
                      ><i class="mdi mdi-arrow-right h5"></i
                    ></a>
                  </div>

                  <p class="text-white-50 mb-0 mt-1">Since last month</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-3 col-md-6">
            <div class="card mini-stat bg-primary text-white">
              <div class="card-body">
                <div class="mb-4">
                  <div class="float-left mini-stat-img mr-4">
                    <img
                      src="../../assets/images/services-icon/03.png"
                      alt=""
                    />
                  </div>
                  <h5 class="font-size-16 text-uppercase mt-0 text-white-50">
                    管理人员活跃数
                  </h5>
                  <h4 class="font-weight-medium font-size-24">
                    8 <i class="mdi mdi-arrow-down text-danger ml-2"></i>
                  </h4>
                  <div class="mini-stat-label bg-warning">
                    <p class="mb-0">- 4%</p>
                  </div>
                </div>
                <div class="pt-2">
                  <div class="float-right">
                    <a href="#" class="text-white-50"
                      ><i class="mdi mdi-arrow-right h5"></i
                    ></a>
                  </div>

                  <p class="text-white-50 mb-0 mt-1">Since last month</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- end row -->

        <div class="row">
          <div class="col-xl-9">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title mb-4">账号活跃度</h4>
                <div class="row">
                  <div class="col-lg-7">
                    <div>
                      <div
                        id="boxone"
                        style="height: 340px; width: 500px"
                      ></div>
                    </div>
                  </div>
                  <div class="col-lg-5">
                    <div class="row">
                      <div class="col-md-6">
                        <div class="text-center">
                          <p class="text-muted mb-4">本月</p>
                          <h3>2219</h3>
                          <p class="text-muted mb-5">
                            本月活跃数占注册用户比例
                          </p>
                          <div
                            id="boxtwo"
                            style="height: 172px; width: 172px"
                          ></div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="text-center">
                          <p class="text-muted mb-4">上月</p>
                          <h3>2012</h3>
                          <p class="text-muted mb-5">
                            上月活跃数占注册用户比例
                          </p>
                          <div
                            id="boxthree"
                            style="height: 172px; width: 172px"
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- end row -->
              </div>
            </div>
            <!-- end card -->
          </div>

          <div class="col-xl-3">
            <div class="card">
              <div class="card-body">
                <div>
                  <h4 class="card-title mb-4">用户分析</h4>
                </div>
                <div class="wid-peity mb-4">
                  <div class="row">
                    <div class="col-md-6">
                      <div>
                        <p class="text-muted">乘客</p>
                        <h5 class="mb-4">1,685</h5>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div
                        id="boxfour"
                        style="height: 80px; width: 130px"
                      ></div>
                    </div>
                  </div>
                </div>
                <div class="wid-peity mb-4">
                  <div class="row">
                    <div class="col-md-6">
                      <div>
                        <p class="text-muted">机组人员</p>
                        <h5 class="mb-4">368</h5>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div
                        id="boxfive"
                        style="height: 80px; width: 130px"
                      ></div>
                    </div>
                  </div>
                </div>
                <div class="wid-peity mb-4">
                  <div class="row">
                    <div class="col-md-6">
                      <div>
                        <p class="text-muted">机场工作人员</p>
                        <h5>158</h5>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div id="boxsix" style="height: 80px; width: 130px"></div>
                    </div>
                  </div>
                </div>
                <div class="wid-peity mb-4">
                  <div class="row">
                    <div class="col-md-6">
                      <div>
                        <p class="text-muted">管理人员</p>
                        <h5 class="mb-4">8</h5>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div
                        id="boxseven"
                        style="height: 80px; width: 130px"
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- end row -->

        <div class="row">
          <div class="col-xl-3">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title mb-4">用户报告</h4>

                <div class="cleafix">
                  <p class="float-left">
                    <i class="mdi mdi-calendar mr-1 text-primary"></i> 7 21 - 8
                    21
                  </p>
                  <h5 class="font-18 text-right">2219</h5>
                </div>

                <div id="boxeight" style="height: 240px; width: 240px"></div>

                <div class="mt-4">
                  <table class="table mb-0">
                    <tbody>
                      <tr>
                        <td>
                          <span class="badge badge-primary">Passenger</span>
                        </td>
                        <td>乘客</td>
                        <td class="text-right">75.9%</td>
                      </tr>
                      <tr>
                        <td><span class="badge badge-success">Crew</span></td>
                        <td>机组人员</td>
                        <td class="text-right">16.6%</td>
                      </tr>
                      <tr>
                        <td><span class="badge badge-warning">Staff</span></td>
                        <td>机场工作人员</td>
                        <td class="text-right">7.1%</td>
                      </tr>
                      <tr>
                        <td><span class="badge badge-success">Admin</span></td>
                        <td>管理人员</td>
                        <td class="text-right">0.4%</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-4">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title mb-4">消息</h4>
                <ol class="activity-feed">
                  <li class="feed-item">
                    <div class="feed-item-list">
                      <span class="date">7 30</span>
                      <span class="activity-text"
                        >机场对所有国内旅客进行健康码查验</span
                      >
                    </div>
                  </li>
                  <li class="feed-item">
                    <div class="feed-item-list">
                      <span class="date">7 20</span>
                      <span class="activity-text"
                        >机场对所有国外回国旅客进行隔离措施</span
                      >
                    </div>
                  </li>
                  <li class="feed-item">
                    <div class="feed-item-list">
                      <span class="date">7 19</span>
                      <span class="activity-text"
                        >机场成功抢救心跳呼吸骤停旅客</span
                      >
                    </div>
                  </li>
                  <li class="feed-item">
                    <div class="feed-item-list">
                      <span class="date">7 15</span>
                      <span class="activity-text"
                        >年内第二场线上直播今日在机场开启</span
                      >
                    </div>
                  </li>
                  <li class="feed-item">
                    <div class="feed-item-list">
                      <span class="date">7 10</span>
                      <span class="activity-text"
                        >首店经济效益助推机场商业品质再升级</span
                      >
                    </div>
                  </li>
                  <li class="feed-item">
                    <div class="feed-item-list">
                      <span class="date">6 30</span>
                      <span class="activity-text"
                        >机场举行庆祝中国共产党成立100周年大会</span
                      >
                    </div>
                  </li>
                </ol>
              </div>
            </div>
          </div>

          <div class="col-xl-5">
            <div class="row">
              <div class="col-md-6">
                <div class="card text-center">
                  <div class="card-body">
                    <div class="py-4">
                      <i
                        class="
                          ion ion-ios-checkmark-circle-outline
                          display-4
                          text-success
                        "
                      ></i>

                      <h5 class="text-primary mt-4">登陆成功</h5>
                      <p class="text-muted">
                        感谢您使用本系统
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="card bg-primary">
                  <div class="card-body">
                    <div class="text-center text-white py-4">
                      <h5 class="mt-0 mb-4 text-white-50 font-size-16">
                        最高用户组成部分
                      </h5>
                      <h1>1685</h1>
                      <p class="font-size-14 pt-1">乘客</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title mb-4">公司宗旨</h4>
                    <p class="text-muted mb-3 pb-4">
                      " Better!Better!!Better!!! "
                    </p>
                    <div class="float-right mt-2">
                      <a href="#" class="text-primary">
                        <i class="mdi mdi-arrow-right h5"></i>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- end row -->
      </div>
      <!-- container-fluid -->
    </div>
  </div>
</template>
 

<script>
import Stomp from 'stompjs'
const optionone = {
  title: {
    text: "用户数据图",
  },
  tooltip: {
    trigger: "axis",
    axisPointer: {
      type: "cross",
      label: {
        backgroundColor: "#6a7985",
      },
    },
  },
  legend: {
    data: ["活跃用户数", "注册用户数"],
  },
  toolbox: {
    feature: {
      saveAsImage: {},
    },
  },
  grid: {
    left: "3%",
    right: "4%",
    bottom: "3%",
    containLabel: true,
  },
  xAxis: [
    {
      type: "category",
      boundaryGap: false,
      data: [
        "2020/09",
        "2020/10",
        "2020/11",
        "2020/12",
        "2021/01",
        "2021/02",
        "2021/03",
        "2021/04",
        "2021/05",
        "2021/06",
        "2021/07",
        "2021/08",
      ],
    },
  ],
  yAxis: {
    type: "value",
  },
  series: [
    {
      name: "活跃用户数",
      type: "line",
      stack: "总量",
      smooth: true,
      areaStyle: {},
      emphasis: {
        focus: "series",
      },
      data: [
        2097, 2115, 2254, 2351, 2412, 2619, 2697, 2515, 2354, 2551, 2012, 2219,
      ],
    },
    {
      name: "注册用户数",
      type: "line",
      stack: "总量",
      smooth: true,
      areaStyle: {},
      emphasis: {
        focus: "series",
      },
      data: [
        2297, 2259, 2458, 2551, 2612, 2719, 2827, 2715, 2435, 2415, 2312, 2419,
      ],
    },
  ],
};
const optiontwo = {
  series: [
    {
      name: "用户组成",
      type: "pie",
      radius: ["40%", "70%"],
      avoidLabelOverlap: false,
      itemStyle: {
        borderRadius: 6,
        borderColor: "#fff",
        borderWidth: 1,
      },
      label: {
        show: false,
        position: "center",
      },
      emphasis: {
        label: {
          show: true,
          fontSize: "10",
          fontWeight: "bold",
        },
      },
      labelLine: {
        show: false,
      },
      data: [
        { value: 2219, name: "活跃用户" },
        { value: 200, name: "冻结用户" },
      ],
    },
  ],
};
const optionthree = {
  series: [
    {
      name: "用户组成",
      type: "pie",
      radius: ["40%", "70%"],
      avoidLabelOverlap: false,
      itemStyle: {
        borderRadius: 6,
        borderColor: "#fff",
        borderWidth: 1,
      },
      label: {
        show: false,
        position: "center",
      },
      emphasis: {
        label: {
          show: true,
          fontSize: "10",
          fontWeight: "bold",
        },
      },
      labelLine: {
        show: false,
      },
      data: [
        { value: 2012, name: "活跃用户" },
        { value: 300, name: "冻结用户" },
      ],
    },
  ],
};
const optionfour = {
  xAxis: {
    type: "category",
    boundaryGap: false,
  },
  yAxis: {
    type: "value",
  },
  series: [
    {
      data: [
        1820, 1632, 1701, 1634, 1425, 1290, 1125, 1330, 1320, 1556, 1654, 1685,
      ],
      type: "line",
      smooth: true,
      areaStyle: {},
    },
  ],
};
const optionfive = {
  xAxis: {
    type: "category",
    boundaryGap: false,
  },
  yAxis: {
    type: "value",
  },
  series: [
    {
      data: [320, 332, 341, 334, 325, 320, 310, 330, 320, 355, 365, 368],
      type: "line",
      smooth: true,
      areaStyle: {},
    },
  ],
};
const optionsix = {
  xAxis: {
    type: "category",
    boundaryGap: false,
  },
  yAxis: {
    type: "value",
  },
  series: [
    {
      data: [182, 163, 171, 164, 142, 129, 112, 130, 130, 156, 154, 158],
      type: "line",
      smooth: true,
      areaStyle: {},
    },
  ],
};
const optionseven = {
  xAxis: {
    type: "category",
    boundaryGap: false,
  },
  yAxis: {
    type: "value",
  },
  series: [
    {
      data: [12, 10, 10, 11, 11, 11, 11, 10, 10, 10, 10, 8],
      type: "line",
      smooth: true,
      areaStyle: {},
    },
  ],
};
const optioneight = {
  series: [
    {
      name: "访问来源",
      type: "pie",
      radius: ["40%", "70%"],
      avoidLabelOverlap: false,
      itemStyle: {
        borderRadius: 6,
        borderColor: "#fff",
        borderWidth: 1,
      },
      label: {
        show: false,
        position: "center",
      },
      emphasis: {
        label: {
          show: true,
          fontSize: "20",
          fontWeight: "bold",
        },
      },
      labelLine: {
        show: false,
      },
      data: [
        { value: 1685, name: "乘客" },
        { value: 358, name: "机组人员" },
        { value: 168, name: "机场工作人员" },
        { value: 8, name: "管理人员" },
      ],
    },
  ],
};
export default {
  // data() {},

  mounted() {
    this.Drawone();
    this.Drawtwo();
    this.Drawthree();
    this.Drawfour();
    this.Drawfive();
    this.Drawsix();
    this.Drawseven();
    this.Draweight();
  },
  methods: {
    //绘制图表
    Drawone: function () {
      // 基于准备好的dom，初始化echarts实例
      var myChart = echarts.init(document.getElementById("boxone"));
      // 使用刚指定的配置项和数据显示图表。
      myChart.setOption(optionone);
    },
    Drawtwo: function () {
      // 基于准备好的dom，初始化echarts实例
      var myChart = echarts.init(document.getElementById("boxtwo"));
      // 使用刚指定的配置项和数据显示图表。
      myChart.setOption(optiontwo);
    },
    Drawthree: function () {
      // 基于准备好的dom，初始化echarts实例
      var myChart = echarts.init(document.getElementById("boxthree"));
      // 使用刚指定的配置项和数据显示图表。
      myChart.setOption(optionthree);
    },
    Drawfour: function () {
      // 基于准备好的dom，初始化echarts实例
      var myChart = echarts.init(document.getElementById("boxfour"));
      // 使用刚指定的配置项和数据显示图表。
      myChart.setOption(optionfour);
    },
    Drawfive: function () {
      // 基于准备好的dom，初始化echarts实例
      var myChart = echarts.init(document.getElementById("boxfive"));
      // 使用刚指定的配置项和数据显示图表。
      myChart.setOption(optionfive);
    },
    Drawsix: function () {
      // 基于准备好的dom，初始化echarts实例
      var myChart = echarts.init(document.getElementById("boxsix"));
      // 使用刚指定的配置项和数据显示图表。
      myChart.setOption(optionsix);
    },
    Drawseven: function () {
      // 基于准备好的dom，初始化echarts实例
      var myChart = echarts.init(document.getElementById("boxseven"));
      // 使用刚指定的配置项和数据显示图表。
      myChart.setOption(optionseven);
    },
    Draweight: function () {
      // 基于准备好的dom，初始化echarts实例
      var myChart = echarts.init(document.getElementById("boxeight"));
      // 使用刚指定的配置项和数据显示图表。
      myChart.setOption(optioneight);
    },
  },
};
</script>

<style scoped>
.main-content {
  margin: 0px;
}
.page-content {
  padding-top: 12px;
}
.text-muted mb-3 pb-4 {
  font-size: 40px;
}
</style>