export const MQ_SERVICE = 'ws://47.98.214.197:61614' // mq服务地址
export const MQ_USERNAME = 'admin' // mq连接用户名
export const MQ_PASSWORD = 'admin' //mq连接密码